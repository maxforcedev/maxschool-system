"use client"

import { StudentRegistrationForm } from "@/components/student/student-registration-form"

export default function StudentRegistrationPage() {
  return <StudentRegistrationForm />
}
