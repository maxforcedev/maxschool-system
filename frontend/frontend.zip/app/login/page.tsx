import LoginPage from "@/login"

export default function Page() {
  return <LoginPage />
}

