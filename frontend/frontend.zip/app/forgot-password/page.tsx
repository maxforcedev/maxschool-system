import ForgotPasswordPage from "@/forgot-password"

export default function Page() {
  return <ForgotPasswordPage />
}
